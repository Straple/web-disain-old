#include "testlib.h"
#include<vector>

using namespace std;


int main(int argc, char* argv[]) {
    registerTestlibCmd(argc, argv);

    int n = inf.readInt();
    vector<int> a(n);
    for (int i = 0; i < n; ++i)
        a[i] = inf.readInt();
    int user_n = ouf.readInt(1, n);
    int user_c = ouf.readInt(1, 1e9);
    int count = 0;
    int corr_n = ans.readInt();
    int corr_c = ans.readInt();

    for (int i = 0; i < n; ++i)
        if (a[i] >= user_c)
            ++count;

    if (count < user_n)
        quitf(_wa, "User answer: %d types of cakes, %d cakes of each type. But there is only %d types of cakes with number of cakes >= %d", user_n, user_c, count, user_c);
    if (user_n * user_c == corr_n * corr_c)
        quitf(_ok, "Correct solution");
    else if (user_n * user_c < corr_n * corr_c)
        quitf(_wa, "There is a better solution");
    else
        quitf(_fail, "Answer is better than jury answer");
}
