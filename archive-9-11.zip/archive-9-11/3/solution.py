n = int(input())
a = [int(input()) for i in range(n)]
a.sort(reverse=True)
ans_n = 0
ans_count = 0
for i in range(n):
    if a[i] * (i + 1) > ans_n * ans_count:
        ans_n = i + 1
        ans_count = a[i]
print(ans_n, ans_count)

