#include <bits/stdc++.h>
#include "testlib.h"

using namespace std;

const int MAX_MOVES = 100000;

bool check_move(int x1, int y1, int x2, int y2)
{
    int dx = abs(x2 - x1);
    int dy = abs(y2 - y1);
    return dx == 1 && dy == 2 || dx == 2 && dy == 1;
}

int main(int argc, char* argv[]) {
    registerTestlibCmd(argc, argv);
    
    int x_finish = inf.readInt();
    int y_finish = inf.readInt();

    int x = 0;
    int y = 0;
    int moves = 0;
    while (!ouf.seekEof())
    {
        int next_x = ouf.readInt();
        int next_y = ouf.readInt();
        ++moves;
        if (moves > MAX_MOVES)
            quitf(_wa, "Total number of moves greater than %d", MAX_MOVES);
        if (!check_move(x, y, next_x, next_y))
            quitf(_wa, "Wrong move #%d: from (%d, %d) to (%d, %d)", moves, x, y, next_x, next_y);
        x = next_x;
        y = next_y;
    }
    if (x != x_finish || y != y_finish)
        quitf(_wa, "Final position of knight is incorrect: knight in the (%d, %d), but finish position is (%d, %d)", x, y, x_finish, y_finish);
    quitf(_ok, "OK, number of moves is %d", moves);
}
