t = int(input())
trains = []
n = int(input())
for i in range(n):
    a = int(input())
    b = int(input())
    trains.append([a, 1])
    trains.append([b + t, -2])
m = int(input())
for i in range(m):
    a = int(input())
    b = int(input())
    trains.append([a, 2])
    trains.append([b + t, -1])
ans = 0
free = [0, 0, 0]
trains.sort()
for t, event in trains:
    if event < 0:
        free[-event] += 1
    else:
        if free[event] == 0:
            ans += 1
            free[event] = 1
        free[event] -= 1
print(ans)

