n = int(input())
m = int(input())
t = int(input())
print(int(((n + m) - ((n + m) ** 2 - 4 * t) ** 0.5) / 4))


