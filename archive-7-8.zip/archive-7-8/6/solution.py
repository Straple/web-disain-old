n = int(input())
m = int(input())
t = int(input())
c = 2 * (n + m) - 4
d = 0
while c <= t and c > 0:
    d += 1
    t -= c
    c -= 8
print(d)
