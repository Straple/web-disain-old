x_finish = int(input())
y_finish = int(input())

x = 0
y = 0

while x < x_finish:
    print(x + 1, y + 2)
    print(x - 1, y + 1)
    print(x + 1, y)
    x += 1
while x > x_finish:
    print(x - 1, y + 2)
    print(x + 1, y + 1)
    print(x - 1, y)
    x -= 1
while y < y_finish:
    print(x + 2, y + 1)
    print(x + 1, y - 1)
    print(x, y + 1)
    y += 1
while y > y_finish:
    print(x + 2, y - 1)
    print(x + 1, y + 1)
    print(x, y - 1)
    y -= 1


    

    
